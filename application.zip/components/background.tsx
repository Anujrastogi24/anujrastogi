import Image from "next/image";
import ParallaxBackground from "./parallax-background";

export default function Background() {
  return (
    <div className="absolute inset-0">
      <ParallaxBackground>
        <Image
          src="/background.webp"
          alt=""
          fill
          priority
          sizes="100vw"
          quality={85}
          className="object-cover object-center md:object-[62%_50%] lg:object-[64%_50%]"
        />
      </ParallaxBackground>

      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 bg-[#05080d]/30"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 bg-[linear-gradient(180deg,rgba(5,8,13,0.62)_0%,rgba(5,8,13,0)_42%)]"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 bg-[linear-gradient(100deg,rgba(5,8,13,0.9)_0%,rgba(5,8,13,0.68)_34%,rgba(5,8,13,0.36)_56%,rgba(5,8,13,0.14)_72%,rgba(5,8,13,0)_100%)]"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 bg-[linear-gradient(0deg,rgba(5,8,13,0.92)_0%,rgba(5,8,13,0.5)_26%,rgba(5,8,13,0)_55%)]"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(90%_60%_at_18%_82%,rgba(92,255,138,0.05)_0%,transparent_55%)]"
      />
    </div>
  );
}