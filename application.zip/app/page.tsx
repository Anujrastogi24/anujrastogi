import Background from "@/components/background";
import Nav from "@/components/nav";
import {
  BetterIdeasIcon,
  BiggerImpactIcon,
  TogetherForwardIcon,
} from "@/components/icons";

const principles = [
  { label: "Better Ideas", Icon: BetterIdeasIcon },
  { label: "Bigger Impact", Icon: BiggerImpactIcon },
  { label: "Together Forward", Icon: TogetherForwardIcon },
];

export default function Home() {
  return (
    <div className="relative h-dvh overflow-hidden">
      <Background />

      <div className="relative z-10 flex h-dvh flex-col">
        <Nav />

        <main className="flex flex-1 flex-col justify-center overflow-hidden px-6 py-6 sm:px-10 sm:py-8 lg:px-16">
          <div className="mx-auto w-full max-w-[1680px]">
            <div className="max-w-xl">
              <h1
                className="animate-fade-up text-[clamp(3rem,9vw,7rem)] font-extrabold uppercase leading-[0.9] tracking-[-0.035em] text-white"
                style={{ animationDelay: "60ms" }}
              >
                <span className="block">Coming</span>
                <span className="block text-accent [text-shadow:0_0_42px_rgba(92,255,138,0.4)]">
                  Soon
                </span>
              </h1>

              <p
                className="animate-fade-up mt-5 max-w-md text-[15px] leading-relaxed text-white/70 sm:text-[17px]"
                style={{ animationDelay: "160ms" }}
              >
                A new space for my projects, ideas, experiments, and everything
                I&apos;m building. Something better is taking shape. Stay tuned.
              </p>

              <div
                className="animate-fade-up mt-8 flex flex-wrap items-center gap-x-9 gap-y-3 border-t border-white/10 pt-5"
                style={{ animationDelay: "450ms" }}
              >
                {principles.map(({ label, Icon }) => (
                  <span
                    key={label}
                    className="flex items-center gap-2.5 font-mono text-[13px] text-white/60"
                  >
                    <Icon className="h-[17px] w-[17px] text-accent/90" />
                    {label}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </main>

        <footer
          className="animate-fade-in w-full"
          style={{ animationDelay: "450ms" }}
        >
          <div className="mx-auto flex w-full max-w-[1680px] items-center justify-center border-t border-white/10 px-6 py-4 sm:px-10 lg:px-16">
            <p className="text-xs text-white/45">
              <span className="font-semibold text-white/75">
                anujrastogi.in
              </span>
              <span aria-hidden className="mx-2 text-white/25">
                ·
              </span>
              © 2026 Anuj Rastogi. All rights reserved.
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}